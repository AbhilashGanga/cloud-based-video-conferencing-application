# cloud-based-video-conferencing-application-using-OpenVidu
A cloud based video conferencing application using OpenVidu library

## Architecture

![Architecture](https://github.com/0-5-blood-prince/cloud-based-video-conferencing-application-using-openvidu/blob/main/system_design.jpeg)

OpenVidu Official Documentation: https://docs.openvidu.io/en/stable/reference-docs/REST-API/


